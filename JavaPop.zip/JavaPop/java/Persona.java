

/**
 * @author albag
 * @version 1.0
 * @created 25-may.-2020 20:19:56
 */
public class Persona {

	private String dni;
	private int edad;
	private String nombre;

	public Persona(){

	}

	public void finalize() throws Throwable {

	}
}//end Persona