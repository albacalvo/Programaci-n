

/**
 * @author albag
 * @version 1.0
 * @created 25-may.-2020 20:19:53
 */
public class Cuenta {

	private Cliente clientes;

	public Cuenta(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param cantidad
	 */
	public void ingresar(int cantidad){

	}
}//end Cuenta