

/**
 * @author albag
 * @version 1.0
 * @created 25-may.-2020 20:19:51
 */
public class Cliente extends Persona {

	public Cliente(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end Cliente