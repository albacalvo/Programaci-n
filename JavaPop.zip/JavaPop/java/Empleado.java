

/**
 * @author albag
 * @version 1.0
 * @created 25-may.-2020 20:19:54
 */
public class Empleado extends Persona {

	public Empleado(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end Empleado