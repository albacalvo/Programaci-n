/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaPop;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author albag
 */
public class PruebaJavaPop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*UtilJavaPop.cargarDatos();
        Cliente comprador = UtilJavaPop.getClientes().get(2);
        Cliente vendedor = UtilJavaPop.getClientes().get(0);
        System.out.println("Comprador: " + comprador);
        System.out.println("Vendedor: " + vendedor);
        System.out.println("Producto: " + vendedor.getProductos().get(0));
        System.out.println("\nSaldo vendedor antes: " + vendedor.getSaldo());
            System.out.println("Saldo comprador antes: " + comprador.getSaldo());
        try {
            UtilJavaPop.comprar(vendedor.getProductos().get(0), comprador);
            System.out.println("\nSaldo vendedor despues: " + vendedor.getSaldo());
            System.out.println("Saldo comprador despues: " + comprador.getSaldo());
            System.out.println(UtilJavaPop.getVentas());
        } catch (IOException ex) {
            Logger.getLogger(PruebaJavaPop.class.getName()).log(Level.SEVERE, null, ex);
        } */
        double a = 6;
        double b = 5;
        System.out.println(a+b);
    }   
}