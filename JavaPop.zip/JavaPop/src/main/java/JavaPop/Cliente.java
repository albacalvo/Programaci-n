package JavaPop;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;
import java.util.TimerTask;
import javax.swing.Timer;

public class Cliente implements Serializable, Comparable<Cliente>{
    //Atributos
    private String DNI;
    private String nombre; 
    private String correo;
    private String clave;
    private Ubicacion ubicacion;
    private long tarjetaCrédito;
    private double saldo;
    private ArrayList<Producto> productos = new ArrayList<>();
    private LocalDate fecha;
    //Constructores

    public Cliente(String DNI, String nombre, String correo, String clave, Ubicacion ubicacion, double saldo, long tarjetaCrédito) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.correo = correo;
        this.clave = clave;
        this.ubicacion = ubicacion;
        this.saldo = saldo;
        this.tarjetaCrédito = tarjetaCrédito;
        this.fecha = LocalDate.now();
    }

    public Cliente() {
    }
    
    //Métodos
    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public ArrayList<Producto> getProductos() {
        return productos;
    }
    
    public void setProductos(ArrayList<Producto> productos){
        this.productos = productos;
    }
    
    public boolean bajaProducto(Producto producto){
        if (productos.contains(producto)){
            productos.remove(producto);
            UtilJavaPop.getProductos().remove(producto);
            return true;
        }
        else{
            return false;
        }
    }
    
    public boolean comprobarSaldo() { 
        LocalDate fechaVencimiento = fecha.plusDays(30);
        LocalDate fechaActual = LocalDate.now();
        if (fechaVencimiento.isBefore(fechaActual)) {
            setSaldo(saldo - 30);
            fecha = fechaVencimiento;
            setFecha(fecha);
            fechaVencimiento = fecha.plusDays(30);
            System.out.println("Ha pasado un mes. Se han restado 30€ de su saldo. Saldo: " + saldo);
            return true;
        }
        else{
            return false;
        }
    }
    public long getTarjetaCrédito() {
        return tarjetaCrédito;
    }

    public void setTarjetaCrédito(long tarjetaCrédito) {
        this.tarjetaCrédito = tarjetaCrédito;
    }
    
    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.DNI);
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (!Objects.equals(this.DNI, other.DNI)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Cliente c) {
        return this.DNI.compareTo(c.getDNI());
    }

    @Override
    public String toString() {
        return "Cliente{" + "DNI=" + DNI + ", nombre=" + nombre + ", correo=" + correo + ", ubicacion=" + ubicacion + ", tarjetaCrédito=" + tarjetaCrédito + ", saldo=" + saldo + ", productos=" + productos + '}';
    }
}