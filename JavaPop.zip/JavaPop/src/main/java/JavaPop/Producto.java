package JavaPop;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Producto implements Serializable, Comparable<Producto> {

    private String titulo;
    private String descripcion;
    private String categoria;
    private String estado;
    private double precio;
    private LocalDate fecha;
    private boolean urgente;
    private LocalDate fechaUrgente;
    private String foto;
    private Cliente cliente;

    public Producto(String titulo, String descripcion, String categoria, String estado, double precio, boolean urgente, String foto, Cliente cliente) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.estado = estado;
        this.precio = precio;
        this.fecha = LocalDate.now();
        this.urgente = urgente;
        if (urgente) {
            fechaUrgente = fecha.plusDays(7);
        }
        this.foto = foto;
        this.cliente = cliente;
        if (!UtilJavaPop.getProductos().contains(this)) {
            this.cliente.getProductos().add(this);
            UtilJavaPop.getProductos().add(this);
        }
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public LocalDate getFechaUrgente() {
        return fechaUrgente;
    }

    public void setFechaUrgente(LocalDate fechaUrgente) {
        this.fechaUrgente = fechaUrgente;
    }

    public boolean isUrgente() {
        return urgente;
    }

    public void setUrgente(boolean urgente) {
        this.urgente = urgente;
        this.fechaUrgente = LocalDate.now();
    }

    public void compruebaCaducidadUrgente() {
        LocalDate fechaVencimiento = fecha.plusDays(7);
        if (urgente == true && fechaVencimiento.isBefore(fechaUrgente)) {
            urgente = false;
            System.out.println("Producto urgente expirado: " + this.toString());
        }
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + Objects.hashCode(this.titulo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        if (!Objects.equals(this.titulo, other.titulo) || !Objects.equals(this.descripcion,other.descripcion) || !Objects.equals(this.categoria,other.categoria) || !Objects.equals(this.estado,other.estado) || !Objects.equals(this.cliente,other.cliente)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Producto p) {
        return this.titulo.compareTo(p.getTitulo());
    }

    @Override
    public String toString() {
        return "Producto{" + "titulo=" + titulo + ", descripcion=" + descripcion + ", categoria=" + categoria + ", estado=" + estado + ", precio=" + precio + ", fecha=" + fecha + ", urgente=" + urgente + cliente.getUbicacion().toString() + ", foto=" + foto + '}';
    }

}
