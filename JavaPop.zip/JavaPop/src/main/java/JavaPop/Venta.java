package JavaPop;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Venta implements Serializable, Comparable<Venta> {

    private Producto producto;
    private Cliente comprador;
    private Cliente vendedor;
    private LocalDate fechaVenta;

    public Venta(Producto producto, Cliente comprador) {
        this.producto = producto;
        this.comprador = comprador;
        this.vendedor = producto.getCliente();
        this.fechaVenta = LocalDate.now();
    }

    public LocalDate getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDate fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public Cliente getVendedor() {
        return vendedor;
    }

    public void setVendedor(Cliente vendedor) {
        this.vendedor = vendedor;
    }

    public Cliente getComprador() {
        return comprador;
    }

    public void setComprador(Cliente comprador) {
        this.comprador = comprador;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.fechaVenta);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Venta other = (Venta) obj;
        if (!Objects.equals(this.fechaVenta, other.fechaVenta)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Venta v) {
        return this.fechaVenta.compareTo(v.getFechaVenta());
    }

    @Override
    public String toString() {
        DateTimeFormatter formatoCorto = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "Venta{" + "producto=" + producto + ", comprador=" + comprador.getDNI() + " - " + comprador.getNombre() + ", vendedor=" + vendedor.getDNI() + " - " + vendedor.getNombre() + ", fechaVenta=" + fechaVenta.format(formatoCorto) + '}';
    }

    public void generaFichaVenta() throws IOException {
        PrintWriter salida = new PrintWriter(new BufferedWriter(new FileWriter("./Facturas/" + this.getFechaVenta() + " - " + this.getComprador().getDNI() + ".txt")));
        Producto p = this.getProducto();
        salida.println("-----------------------------  Ficha Venta  -----------------------------");
        salida.println("\n");
        salida.println(p.getTitulo() + "  -  " + p.getDescripcion()+ "  -  " + p.getPrecio());
        salida.println("\n");
        salida.println("Comprador: " + this.getComprador().getNombre() + "  DNI: " + this.getComprador().getDNI());
        salida.println("Vendedor: " + this.getVendedor().getNombre() + "  DNI: " + this.getVendedor().getDNI());
        salida.println("-------------------------------------------------------------------------");
        salida.close();

        //UtilJavaPop.abrirFichero("./Facturas/" + this.getFechaVenta() + " - " + this.getComprador().getDNI() + ".txt");

    }
}
