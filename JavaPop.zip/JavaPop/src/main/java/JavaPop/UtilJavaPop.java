package JavaPop;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class UtilJavaPop {
    
    private static ArrayList <Producto> productos = new ArrayList<>();
    private static Producto producto;
    private static ArrayList <Cliente> clientes = new ArrayList<>();
    private static Cliente cliente;
    private static ArrayList <Venta> ventas = new ArrayList<>();
    private static Venta venta;
    private static double precioproducto;
    private static double saldovendedor;
    private static double saldocomprador;
    
    private static Cliente clienteActivo;
    private static double saldo;

    public static Cliente getClienteActivo() {
        return clienteActivo;
    }

    public static void setClienteActivo(Cliente cliente) {
        UtilJavaPop.clienteActivo = cliente;
    }

    public static ArrayList<Venta> getVentas() {
        return ventas;
    }

    public static void setVentas(ArrayList <Venta> ventas) {
        UtilJavaPop.ventas = ventas;
    }
    public static ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public static void setClientes(ArrayList <Cliente> clientes) {
        UtilJavaPop.clientes = clientes;
    }

    public static ArrayList<Producto> getProductos() {
        return productos;
    }

    public static void setProductos(ArrayList <Producto> productos) {
        UtilJavaPop.productos = productos;
    }
    
    public static void añadirSaldo(double dinero, Cliente c){
        saldo = UtilJavaPop.getClienteActivo().getSaldo();
        UtilJavaPop.getClienteActivo().setSaldo(dinero + saldo);
        actualizaSaldos();
    }
    
    public static void abrirFichero(String ruta) throws IOException{
        File objetofile = new File(ruta);
        Desktop.getDesktop().open(objetofile);
    }
    
    public static boolean altaCliente(Cliente cliente){
        if(!clientes.contains(cliente)){
            clientes.add(cliente);
            actualizaProductos();
            return true;
        }
        else{
            return false;
        }
    }
    
    public static boolean bajaCliente(Cliente cliente){
        if (clientes.contains(cliente)){
            clientes.remove(cliente);
            actualizaProductos();
            return true;
        }
        else{
            return false;
        }
    }
    
    public Cliente buscaCliente(String DNI){
        Collections.sort(clientes);
        Cliente c = new Cliente();
        c.setDNI(DNI);
        int pos = Collections.binarySearch(clientes, c);
        if (pos>= 0){
            cliente = clientes.get(pos);
        }
        else{
            cliente = null;
        }
        return cliente;
    }
    
    public static void actualizaProductos(){
        productos.clear();
        for (Cliente c : clientes) {
            for (Producto p : c.getProductos()){
                p.compruebaCaducidadUrgente();
            }
            productos.addAll(c.getProductos());
        }
    }
    public static void actualizaSaldos(){
        for (Cliente c : clientes) {
            c.comprobarSaldo();
        }
    }
    public static ArrayList<Producto> ordenaProductos(String categoria, String criterio, Ubicacion ubicacion){
        actualizaProductos();
        ArrayList<Producto> resultado = new ArrayList();
        List<Producto> resultadoCategoria, resultadoCriterio, resultadoProximos, resultadoNoProximos;
        
        //Comparador para ordenar los productos por codigo postal
        Comparator CompCP = new Comparator<Producto>(){
            @Override
            public int compare (Producto p1, Producto p2){
                Integer cp1 = p1.getCliente().getUbicacion().getCodigoPostal();
                Integer cp2 = p2.getCliente().getUbicacion().getCodigoPostal();
                return cp1.compareTo(cp2);
            }
        };
        
        //Comparador para ordenar productos urgentes en orden normal
        Comparator CompU = new Comparator<Producto>(){
            @Override
            public int compare(Producto p1, Producto p2){
                Boolean b1 = p1.isUrgente();
                Boolean b2 = p2.isUrgente();
                return b1.compareTo(b2);
            }
        };
        
        //Seleccionamos los productos de la categoria
        resultadoCategoria = productos.stream().filter(p -> p.getCategoria().equals(categoria)).sorted().collect(Collectors.toList());
        System.out.println("resultadoCategoria: ");
        resultadoCategoria.forEach(System.out::println);
        
        //Seleccionamos los productos que cumplan el criterio de búsqueda
        resultadoCriterio = (List<Producto>) resultadoCategoria.stream().filter(p -> p.getTitulo().contains(criterio)).sorted(CompCP).collect(Collectors.toList());
        System.out.println("resultadoCriterio: ");
        resultadoCriterio.forEach(System.out::println);
        
        resultadoProximos = (List<Producto>) resultadoCriterio.stream().filter(p -> p.getCliente().getUbicacion().getCpMuyProximo() == ubicacion.getCpMuyProximo()
                || p.getCliente().getUbicacion().getCpProximo() == ubicacion.getCpProximo()).sorted(CompU).collect(Collectors.toList());
        Collections.reverse(resultadoProximos);
        System.out.println("resultadoProximos: ");
        resultadoProximos.forEach(System.out::println);
        resultadoNoProximos = (List<Producto>) resultadoCriterio.stream().filter(p -> p.getCliente().getUbicacion().getCpMuyProximo() != ubicacion.getCpMuyProximo()
                && p.getCliente().getUbicacion().getCpProximo() != ubicacion.getCpProximo()).sorted(CompU).collect(Collectors.toList());
        System.out.println("resultadoNoProximos: ");
        resultadoNoProximos.forEach(System.out::println);
        
        //Componemos el resultado
        resultado.addAll(resultadoProximos);
        resultado.addAll(resultadoNoProximos);
        System.out.println("resultadoFinal: ");
        resultado.forEach(System.out::println);
        ArrayList<Producto> borrables = new ArrayList();
        resultado.stream().filter(prod -> (prod.getCliente().equals(clienteActivo))).forEachOrdered(prod -> {
            borrables.add(prod);
        });
        resultado.removeAll(borrables);
        return resultado;
    }
    
    public static void comprar(Producto producto, Cliente comprador) throws IOException {
        venta = new Venta(producto, comprador);
        ventas.add(venta);
        venta.generaFichaVenta();
        producto.getCliente().bajaProducto(producto);
        saldovendedor = producto.getCliente().getSaldo();
        precioproducto = producto.getPrecio();
        saldocomprador = comprador.getSaldo();
        producto.getCliente().setSaldo(saldovendedor + precioproducto);
        UtilJavaPop.getClientes().remove(comprador);
        comprador.setSaldo(saldocomprador - precioproducto);
        UtilJavaPop.getClientes().add(comprador);
        actualizaProductos();
    }
   
    public static ArrayList<Venta> ordenaVentas(LocalDate fecha){
        ArrayList<Venta> resultado = new ArrayList<>();
        resultado.addAll(ventas.stream().filter(v -> v.getFechaVenta().isEqual(fecha) || v.getFechaVenta().isAfter(fecha)).collect(Collectors.toList()));
        return resultado;
    }
    
    public static void cargarDatos() {
        try{
            FileInputStream istream = new FileInputStream("copiasegJavaPop.dat");
            ObjectInputStream ois = new ObjectInputStream(istream);
            productos = (ArrayList<Producto>) ois.readObject();
            clientes = (ArrayList<Cliente>) ois.readObject();
            ventas = (ArrayList<Venta>) ois.readObject();
            istream.close();
        }
        catch (IOException ioe){
            System.out.println("Error de IO: " + ioe.getMessage());
        }
        catch(ClassNotFoundException cnfe){
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        }
        catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public static void guardarDatos(){
        try{
            if (!clientes.isEmpty()){
                FileOutputStream ostream = new FileOutputStream("copiasegJavaPop.dat");
                ObjectOutputStream oos = new ObjectOutputStream(ostream);
                oos.writeObject(productos);
                oos.writeObject(clientes);
                oos.writeObject(ventas);
                ostream.close();
            }
            else{
                System.out.println("Error: No hay datos...");
            }
        }
        catch (IOException ioe){
            System.out.println("Error de IO: " + ioe.getMessage());
        }
        catch (Exception e){
            System.out.println("Error: " +  e.getMessage());
        }
    }
}