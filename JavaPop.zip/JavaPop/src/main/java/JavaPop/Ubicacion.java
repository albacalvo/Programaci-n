package JavaPop;

import java.io.Serializable;

public class Ubicacion implements Serializable {
    
    private String ciudad;    
    private int codigoPostal;
    private int cpProximo;
    private int cpMuyProximo;
    private static final long serialVersionUID = 1L;
    
    public Ubicacion(String ciudad, int codigoPostal) {
        this.ciudad = ciudad;
        this.codigoPostal = codigoPostal;
        this.cpProximo = codigoPostal/100;
        this.cpMuyProximo = cpMuyProximo/1000;
    }

    public int getCpMuyProximo() {
        return cpMuyProximo;
    }

    public void setCpMuyProximo(int cpMuyProximo) {
        this.cpMuyProximo = cpMuyProximo;
    }

    public int getCpProximo() {
        return cpProximo;
    }

    public void setCpProximo(int cpProximo) {
        this.cpProximo = cpProximo;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
        this.cpMuyProximo = codigoPostal/100;
        this.cpProximo = codigoPostal/1000;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 47 * hash + this.codigoPostal;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ubicacion other = (Ubicacion) obj;
        if (this.codigoPostal != other.codigoPostal) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Ubicacion{" + "ciudad=" + ciudad + ", codigoPostal=" + codigoPostal + '}';
    }    
}