package JavaPop;

public class ClienteProfesional extends Cliente{
     //Atributos
    private String descripción;
    private String horario;  
    private String teléfono;   
    private String web;
    
    //Constructor
    public ClienteProfesional(String descripción, String horario, String teléfono, String web, String DNI, String nombre, String correo, String clave, Ubicacion ubicacion, double saldo, long tarjetaCrédito) {
        super(DNI, nombre, correo, clave, ubicacion, saldo, tarjetaCrédito);
        this.descripción = descripción;
        this.horario = horario;
        this.teléfono = teléfono;
        this.web = web;
    }

    //Métodos
    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(String teléfono) {
        this.teléfono = teléfono;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getDescripción() {
        return descripción;
    }

    public void setDescripción(String descripción) {
        this.descripción = descripción;
    }

    @Override
    public String toString() {
        return super.toString() + "ClienteProfesional{" + "descripcion=" + descripción + ", horario=" + horario + ", tel\u00e9fono=" + teléfono + ", web=" + web + '}';
    }
}