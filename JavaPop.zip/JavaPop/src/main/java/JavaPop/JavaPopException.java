package JavaPop;

public class JavaPopException extends Exception{
    
    public static String ERROR_MESSAGE = "Los datos introducidos son incorrectos";
    
    public JavaPopException() {
        super("Se ha producido una excepción en la aplicación");
    }
    
    public JavaPopException(String txt) {
        super(txt);
    }
}
